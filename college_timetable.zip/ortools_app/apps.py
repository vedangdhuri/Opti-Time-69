from django.apps import AppConfig


class OrtoolsAppConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'ortools_app'
